export { default as Home } from './Home/Home';
export { default as GameList } from './GameList/GameList';
export { default as GameDetails } from './GameDetails/GameDetails';
export { default as NotFound } from './NotFound/NotFound';
