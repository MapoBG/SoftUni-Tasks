declare module 'react-image-and-background-image-fade';
