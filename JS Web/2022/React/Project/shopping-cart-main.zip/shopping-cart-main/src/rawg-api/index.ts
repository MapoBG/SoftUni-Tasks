export { gameList } from './gameList';
export { gameScreenshots } from './gameScreenshots';
export { gameDetails } from './gameDetails';
